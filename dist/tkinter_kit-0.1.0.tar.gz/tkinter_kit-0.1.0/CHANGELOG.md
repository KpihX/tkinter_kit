## 0.1.0

- Simplification of access to functions by bypassing func in importation!
