## 0.1.1

- correction of some incoherences

## 0.1.0

- Simplification of access to functions by bypassing func in importation!
